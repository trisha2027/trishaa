// Add all of these using statements at the top of the file
using Microsoft.AspNetCore.Mvc;
using BajajCentra.Models;
using Google.Authenticator;
using System; // Required for Guid

namespace BajajCentra.Controllers
{
    public class TwoFactorController : Controller
    {
        private const string Issuer = "BajajCentra";

        [HttpGet]
        public IActionResult Setup()
        {
            var secretKey = Guid.NewGuid().ToString().Replace("-", "").Substring(0, 10);
            
            TwoFactorAuthenticator tfa = new TwoFactorAuthenticator();
            var setupInfo = tfa.GenerateSetupCode(Issuer, "user@example.com", secretKey, false, 3);

            TempData["SecretKey"] = secretKey;

            var viewModel = new TwoFactorSetupViewModel
            {
                ManualSetupKey = setupInfo.ManualEntryKey,
                QrCodeImageUrl = setupInfo.QrCodeSetupImageUrl
            };

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Setup(TwoFactorSetupViewModel model)
        {
            var secretKey = TempData["SecretKey"]?.ToString();
            if (string.IsNullOrEmpty(secretKey) || string.IsNullOrEmpty(model.VerificationCode))
            {
                ModelState.AddModelError(string.Empty, "The verification code is invalid or has expired. Please try again.");
                
                // If the key is gone, we must redirect to restart the process
                return RedirectToAction("Setup");
            }

            TwoFactorAuthenticator tfa = new TwoFactorAuthenticator();
            bool isCorrectPin = tfa.ValidateTwoFactorPIN(secretKey, model.VerificationCode);

            if (isCorrectPin)
            {
                // On success, redirect to the home page
                return RedirectToAction("Index", "Home");
            }
            else
            {
                // On failure, show an error and display the page again with the same QR code
                var setupInfo = tfa.GenerateSetupCode(Issuer, "user@example.com", secretKey, false, 3);
                var viewModel = new TwoFactorSetupViewModel
                {
                    ManualSetupKey = setupInfo.ManualEntryKey,
                    QrCodeImageUrl = setupInfo.QrCodeSetupImageUrl
                };

                ViewData["ErrorMessage"] = "The verification code is incorrect. Please try again.";
                TempData.Keep("SecretKey"); // Keep the secret key for the next attempt
                return View(viewModel);
            }
        }
    }
}
