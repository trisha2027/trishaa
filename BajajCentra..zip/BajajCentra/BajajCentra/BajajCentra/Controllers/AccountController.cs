using Microsoft.AspNetCore.Mvc;
using BajajCentra.Models;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

namespace BajajCentra.Controllers
{
    public class AccountController : Controller
    {
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                return Json(new { success = false, message = string.Join(" ", errors) });
            }

            // Check the standard username and password
            if (model.Username == "bajaj" && model.Password == "centra@2025")
            {
                // If credentials are correct, create the user's identity claims.
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, model.Username),
                    new Claim("FullName", "Bajaj User"),
                    new Claim(ClaimTypes.Role, "Administrator"),
                };

                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                var authProperties = new AuthenticationProperties
                {
                    // This makes the cookie persistent if "Remember Me" was checked.
                    IsPersistent = model.RememberMe
                };

                // Sign the user in and create the authentication cookie.
                await HttpContext.SignInAsync(
                    CookieAuthenticationDefaults.AuthenticationScheme,
                    new ClaimsPrincipal(claimsIdentity),
                    authProperties);

                // Return a success response, redirecting to the Home page.
                return Json(new { success = true, redirectUrl = Url.Action("Index", "Home") });
            }
            else
            {
                // If credentials are wrong, return a failure response with an error message.
                return Json(new { success = false, message = "Invalid username or password." });
            }
        }

        public async Task<IActionResult> Logout()
        {
            // Clear the authentication cookie.
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            // Redirect the user back to the login page.
            return RedirectToAction("Login", "Account");
        }
    }
}
