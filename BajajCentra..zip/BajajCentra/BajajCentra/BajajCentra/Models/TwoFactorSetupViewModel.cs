// In Models/TwoFactorSetupViewModel.cs
namespace BajajCentra.Models
{
    public class TwoFactorSetupViewModel
    {
        public string ManualSetupKey { get; set; }
        public string QrCodeImageUrl { get; set; }
        public string VerificationCode { get; set; }
    }
}
