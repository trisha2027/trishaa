namespace BajajCentra.Models
{
    public class CommunicationViewModel
    {
        // You can add properties here later if needed
    }
}
