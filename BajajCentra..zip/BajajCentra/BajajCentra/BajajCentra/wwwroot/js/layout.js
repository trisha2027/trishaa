// Sidebar open/close
const app = document.getElementById('app');
const toggleSidebarBtn = document.getElementById('toggleSidebar');
toggleSidebarBtn.addEventListener('click', () => {
    app.classList.toggle('collapsed');
    // Update aria-label for accessibility
    const collapsed = app.classList.contains('collapsed');
    toggleSidebarBtn.setAttribute('aria-label', collapsed ? 'Expand sidebar' : 'Collapse sidebar');
});

// Configuration submenu toggle
const configBtn = document.getElementById('configBtn');
const configSub = document.getElementById('configSub');
configBtn.addEventListener('click', () => {
    const isOpen = configSub.classList.toggle('open');
    configBtn.setAttribute('aria-expanded', String(isOpen));
});
