using Microsoft.AspNetCore.Identity;

public class ApplicationUser : IdentityUser
{
    // Add these two properties here
    public string? TotpSecretKey { get; set; }
    public bool IsTotpEnabled { get; set; }
}
